document.addEventListener("DOMContentLoaded", function(){
    const formCadastro = document.querySelector("form");
    
    if(formCadastro){
        formCadastro.addEventListener("submit", function (e){
            e.preventDefault(); // impede o envio do formulário

            const nome = document.getElementById("nome").value.trim();
            const email = document.getElementById("email").value.trim();
            const cpf = document.getElementById("cpf").value.trim();
            const telefone = document.getElementById("telefone").value.trim();
            const senha = document.getElementById("senha").value.trim();
            const confirmarSenha = document.getElementById("confirmar-senha").value.trim();

            if(!nome || !email || !cpf || !telefone || !senha || !confirmarSenha){
                // Exibir modal de erro
                const modalErroCampos = document.getElementById("modalErroCampos");
                if(modalErroCampos){
                    modalErroCampos.style.display = "flex";
                }
                return; // para aqui
            }



            // Senha e Confirme a Senha
            if (senha !== confirmarSenha) {
                const modalErroSenhas = document.getElementById("modalErroSenhas");
                if (modalErroSenhas) {
                    modalErroSenhas.style.display = "flex";
                }
                return;
            }


            // se tudo estiver preenchido, redireciona
            window.location.href = "index.html";
        });
    }


    // CPF
    const inputCPF = document.getElementById("cpf");
    if(inputCPF) {
        inputCPF.addEventListener("input", function (e) {
            let value = e.target.value.replace(/\D/g, '') // remove nao numeros
            value = value.slice(0, 11); // limita a 11 digitos

            if(value.length > 9){
                value = value.replace(/(\d{3})(\d{3})(\d{3})(\d{1,2})/, "$1.$2.$3-$4");
            } else if (value.length > 6) {
                value = value.replace(/(\d{3})(\d{3})(\d{1,3})/, "$1.$2.$3");
            } else if (value.length > 3) {
                value = value.replace(/(\d{3})(\d{1,3})/, "$1.$2");
            }

            e.target.value = value; 
        });
    }


    // Telefone
    const inputTelefone = document.getElementById("telefone");
    if(inputTelefone) {
        inputTelefone.addEventListener("input", function (e){
            let value = e.target.value.replace(/\D/g, ''); // so numeros
            value = value.slice(0, 11); // limita a 11 digitos (DDD incluso)

            if(value.length > 6) {
                value = value.replace(/(\d{2})(\d{5})(\d{0,4})/, "($1) $2-$3");
            } else if (value.length > 2) {
                value = value.replace(/(\d{2})(\d{0,5})/, "($1) $2");
            } else {
                value = value.replace(/(\d{0,2})/, "($1");
            }

            e.target.value = value;
        });
    }

    document.getElementById("btnFecharErroSenhas").addEventListener("click", () => {
        document.getElementById("modalErroSenhas").style.display = "none"; 
    });
    
    document.getElementById("btnFecharErroCadastro").addEventListener("click", () => {
        document.getElementById("modalErroCampos").style.display = "none"; 
    });

    // modal Carregamento Cadastro
    const btnFecharErroCadastro2 = document.getElementById("btnFecharErroCadastro2");
    if(btnFecharErroCadastro2){
        btnFecharErroCadastro2.addEventListener("click", function(){
            document.getElementById("modalErroCarregamentoCadastro").style.display = "none";
        });
    }
        
    function abrirModalErroCarregamentoCadastro() {
        const modal = document.getElementById("modalErroCarregamentoCadastro");
        if (modal) {
            modal.style.display = "flex";
        } else {
            console.error("Modal de carregamento não encontrado!");
        }
    }
                
        
    setTimeout(abrirModalErroCarregamentoCadastro, 1000); // abre o modal 1s depois do carregamento
    
    document.getElementById("btnFecharErroCarregamentoCadastro").addEventListener("click", () => {
        document.getElementById("modalErroCarregamentoCadastro").style.display = "none"; 
    });
});